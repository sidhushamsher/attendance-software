<?php
session_start();
include 'vendor/php/teacher_api.php';
$obj	=	new api();
$sql	=	"SELECT * FROM timetable";
$sqlQ	=	$conn_obj->sqlQuery_S($sql);
$data	=	mysqli_fetch_assoc($sqlQ['exe']);
$in_time_start_limt		=	$data['first_zone_hour'].''.$data['first_zone_mintue'];
$in_time_end_limt		=	$data['second_zone_hour'].''.$data['second_zone_mintue'];
$out_time_start_limt	=	$data['third_zone_hour'].''.$data['third_zone_mintue'];
$today_date				=	date('d-m-Y');
$current_time			=	date('Hi');
$sql1					=	"SELECT * FROM att_details WHERE staff_uniqid='".$_SESSION['user_logged_in']['staff_uniqid']."' AND att_date='$today_date'";
$sql1Q					=	$conn_obj->sqlQuery_S($sql1);
$data1					=	mysqli_fetch_assoc($sql1Q['exe']);
$s_status				=	$data1['att_status'];
//AFTER SUBMIT
if(isset($_POST['mark_attendace'])){
	if ($s_status == '1') {
		# code...
		$sqlu 	= 	"UPDATE att_details SET att_in_time='$current_time', att_in_time_status='2', att_in_time_maked_by='2', att_status='2' WHERE staff_uniqid = '".$data1['staff_uniqid']."' AND att_date='$today_date'";
	}else if($s_status == '2' && $out_time_start_limt < $current_time ){
		$sqlu 	= 	"UPDATE att_details SET att_out_time='$current_time', att_out_time_status='2', att_out_time_maked_by='2', att_total_time='8HR', att_status='3' WHERE staff_uniqid = '".$data1['staff_uniqid']."' AND att_date='$today_date'";
	}
	$conn_obj->sqlQuery_U($sqlu);
	$conn_obj->go_self();
}
//BEFORE SUBMIT
$sql1					=	"SELECT * FROM att_details WHERE staff_uniqid='".$_SESSION['user_logged_in']['staff_uniqid']."' AND att_date='$today_date'";
$sql1Q					=	$conn_obj->sqlQuery_S($sql1);
$data1					=	mysqli_fetch_assoc($sql1Q['exe']);
$s_status				=	$data1['att_status'];
if ($in_time_start_limt > $current_time && $s_status == 1) {
	# code...
	echo "You are early.";
}elseif($in_time_end_limt < $current_time && $s_status == 1){
	# code...
	echo "You are late.";
}elseif($out_time_start_limt > $current_time && $s_status == 2){
	# code...
	echo "Your attendance marked wait for 7:00 PM to mark again.";
}elseif ($current_time > $out_time_start_limt && $s_status == 1) {
	# code...
	echo "You are absent today.";
}elseif ($s_status == 3) {
	# code...
	echo "Great job.";
}else{
	echo "mark your attendance";
	?>
	<form method="post">
		<input type="submit" name="mark_attendace">
	</form>
	<?php
}

//AFTER SUBMIT
if(isset($_POST['mark_attendace'])){
	if ($s_status == '1') {
		# code...
		$sqlu 	= 	"UPDATE att_details SET att_in_time='$current_time', att_in_time_status='2', att_in_time_maked_by='2', att_status='2' WHERE staff_uniqid = '".$data1['staff_uniqid']."' AND att_date='$today_date'";
	}else if ($s_status == '2' && $out_time_start_limt < $current_time ) {
		# code...
		$sqlu 	= 	"UPDATE att_details SET att_out_time='$current_time', att_out_time_status='2', att_out_time_maked_by='2', att_total_time='8HR', att_status='3' WHERE staff_uniqid = '".$data1['staff_uniqid']."' AND att_date='$today_date'";
	}
	$conn_obj->sqlQuery_U($sqlu);
	$conn_obj->go_self();

}
?>
