<?php
session_start();
include 'vendor/php/teacher_api.php';
$obj	=	new api();
?>
<html dir="ltr" lang="en-US">
   <head>
      <?php
      $obj->head_script();
      ?>
   </head>
   <body>
      <?php
      $obj->nav_bar();
      $obj->main('dashboard');
      /*$obj->main('addemp');
      $obj->main('timeset');
      $obj->main('viewemp');*/
      $obj->footer_script();
      ?>


   </body>
</html>