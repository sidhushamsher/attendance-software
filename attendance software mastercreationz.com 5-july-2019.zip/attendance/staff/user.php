<html dir="ltr" lang="en-US">
   <head>
      <title>Attendance System</title>
      <meta http-equiv="content-type" content="text/html; charset=utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <meta name="author" content="" />
      <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,900&display=swap" rel="stylesheet" type="text/css" />
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800&display=swap" rel="stylesheet">
      <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
      <link rel="stylesheet" href="vendor/css/bootstrap.min.css" type="text/css" />
      <link rel="stylesheet" href="vendor/css/navigation.css" type="text/css">
      <link rel="stylesheet" href="vendor/css/style.css" type="text/css" />
      <link rel="stylesheet" href="vendor/css/responsive.css" type="text/css" />
   </head>
   <body>
      <nav class="navbar navbar-expand-lg navbar-light">
         <div class="container-fluid">
            <a class="navbar-brand" href="#"><img src="vendor/img/logo-img.png" class="img-fluid"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
               <p class="header-title">Time<br/>
               Management</p>
               <ul class="navbar-nav ml-auto">
                  <li class="nav-item dropdown">
                     <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     <img src="vendor/img/img1.jpg" class="img-fluid profile-pic">
                     </a>
                     <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <div class="az-header-profile">
                           <div class="az-img-user">
                              <img src="vendor/img/img1.jpg" alt="">
                           </div>
                           <!-- az-img-user -->
                           <h6>Aziana Pechon</h6>
                        </div>
                        <a href="#" class="dropdown-item"><i class="fa fa-user mr-2"></i> My Profile</a>
                        <a href="" class="dropdown-item"><i class="fa fa-sign-out mr-2"></i> Log Out</a>
                     </div>
                  </li>
               </ul>
            </div>
         </div>
      </nav>
      <!---main-body-->
      <div id="wrapper">
         <!-----left-naviagtion--->
         <div class="pr-0 sidebar">
         <nav class="sidebar-offcanvas" id="sidebar">
            <ul class="d-block">
               <li class="nav-item active">
                  <a class="nav-link" href="index.html">
                  <span class="menu-title">Dashboard</span>
                  <i class="fa fa-home"></i>
                  </a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="#">
                  <span class="menu-title">Attendance History</span>
                  <i class="fa fa-file-o" aria-hidden="true"></i>
                  </a>
               </li>
            </ul>
         
         </nav>
         </div>
         <!-----dashboard--->
         <div id="content-wrapper" class="pt-4 px-4">
            <div class="container" id="dashboard">
               <div class="row">
                  <div class="col-12 mb-5">
                     <div class="d-flex align-items-center">
                        <span class="icon-box mr-3"><i class="fa fa-home"></i></span> 
                        <h2 class="top-heading">Dashboard</h2>
                     </div>
                  </div>
                  <div class="col-md-8 col-12">
                     <div class="card">
                        <div class="card-body">
                           <div class="current-date-box">
                              <span class="ct-date"> Friday, 28th June, 2019</span>
                           </div>
                           <div class="checkin-box">
                              <span class="checkin d-block">
                              <button type="submit" class="btn btn-lg btn-red mt-0" href="#" disabled>Check In</button>
                              <time>09:30:50</time>
                              </span>
                              <span class="checkout d-block mt-4">
                              <button type="submit" class="btn btn-red btn-lg mt-0" href="#">Check Out</button>
                              <time>07:30:50</time>
                              </span>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-4 col-12">
                     <div class="card">
                        <div class="card-body">
                           <div class="current-date-box">
                              <span class="ct-date">Current Time</span>
                           </div>
                           <div style="text-align:center;padding:1em 0;"><iframe src="https://www.zeitverschiebung.net/clock-widget-iframe-v2?language=en&size=medium&timezone=Asia%2FKolkata" width="100%" height="115" frameborder="0" seamless></iframe> </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-----edit-profile--->
            <div class="container mt-5" id="add-employee">
               <div class="row">
                  <div class="col-12">
                     <div class="d-flex align-items-center">
                        <span class="icon-box mr-3"><i class="fa fa-user-o"></i></span> 
                        <h2 class="top-heading">Your Profile</h2>
                     </div>
                  </div>
                  <div class="col-md-7 col-12">
                     <div class="card mt-5">
                        <div class="card-body">
                           <form>
                              <div class="form-group mt-0">
                                 <label for="exampleInputPassword1">Old Password</label>
                                 <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                              </div>
                              
                              <div class="form-group">
                                 <label for="exampleInputPassword1">New Password</label>
                                 <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                              </div>
                              <div class="form-group">
                                 <label for="exampleInputConfirmPassword1">Confirm Password</label>
                                 <input type="password" class="form-control" id="exampleInputConfirmPassword1" placeholder="Password">
                              </div>
                              <button type="submit" class="btn btn-lg" href="#">Update</button>
                           </form>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-5 col-12">
                     <div class="card mt-5">
                        <div class="card-body mx-auto">
                           <form>
                              <div class="pie-chart">
                                 <img src="vendor/img/download.png" alt="avatar" class="pie-avatar img-circle">
                              </div>
                              <div class="form-group">
                                 <input type="file" class="form-control-file" id="exampleFormControlFile1">
                              </div>
                              <button type="submit" class="btn btn-lg" href="#">Update</button>
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-----attendance-history--->
            <div class="container mt-5" id="attendance-history">
               <div class="row">
                  <div class="col-12 mb-5">
                     <div class="d-flex align-items-center">
                        <span class="icon-box mr-3"><i class="fa fa-file-o"></i></span> 
                        <h2 class="top-heading">Attendance History</h2>
                     </div>
                  </div>
                  <div class="col-12">
                     <div class="table-wrapper w-100 rounded">
                        <div class="text-center bg-light py-3 rounded">
                                 <span class="month-title">July 2019</span>
                        </div>
                        <div class="table-filter mt-4">
                           <div class="row">
                              <div class="col-12">
                                 <div class="d-flex justify-content-between" >
                                    <button class="btn btn-lg mt-0"> < PREV</button>
                                    <button class="btn btn-lg mt-0">NEXT > </button>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <table class="table table-striped table-hover">
                           <thead>
                              <tr>
                                 <th>No.</th>
                                 <th>Name</th>
                                 <th>Date</th>
                                 <th>Check In</th>
                                 <th>IP Address</th>
                                 <th>Check Out</th>
                              </tr>
                           </thead>
                           <tbody>
                              <tr>
                                 <td>1</td>
                                 <td>Aziana Pechon</a></td>
                                 <td>1-07-2019</td>
                                 <td>09:30:02</td>
                                 <td>192.188.1.2</td>
                                 <td>07:15:42</td>
                              </tr>
                              <tr>
                                 <td>2</td>
                                 <td>Aziana Pechon</a></td>
                                 <td>2-07-2019</td>
                                 <td>09:30:02</td>
                                 <td>192.188.1.2</td>
                                 <td>07:15:42</td>
                              </tr>
                              <tr>
                                 <td>3</td>
                                 <td>Aziana Pechon</a></td>
                                 <td>3-07-2019</td>
                                 <td>09:30:02</td>
                                 <td>192.188.1.2</td>
                                 <td>07:15:42</td>
                              </tr>
                              <tr>
                                 <td>4</td>
                                 <td>Aziana Pechon</a></td>
                                 <td>4-07-2019</td>
                                 <td>09:30:02</td>
                                 <td>192.188.1.2</td>
                                 <td>07:15:42</td>
                              </tr>
                              <tr>
                                 <td>5</td>
                                 <td>Aziana Pechon</a></td>
                                 <td>5-07-2019</td>
                                 <td>09:30:02</td>
                                 <td>192.188.1.2</td>
                                 <td>07:15:42</td>
                              </tr>
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="vendor/js/bootstrap.min.js"></script>
      <script src="vendor/js/main.js"></script>
   </body>
</html>