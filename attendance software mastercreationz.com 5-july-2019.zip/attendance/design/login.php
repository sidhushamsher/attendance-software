<html dir="ltr" lang="en-US">
   <head>
      <title>Attendance System</title>
      <meta http-equiv="content-type" content="text/html; charset=utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <meta name="author" content="" />
      <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,900&display=swap" rel="stylesheet" type="text/css" />
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800&display=swap" rel="stylesheet">
      <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
      <link rel="stylesheet" href="vendor/css/bootstrap.min.css" type="text/css" />
      <link rel="stylesheet" href="vendor/css/navigation.css" type="text/css">
      <link rel="stylesheet" href="vendor/css/style.css" type="text/css" />
      <link rel="stylesheet" href="vendor/css/responsive.css" type="text/css" />
   </head>
   <body>
      <!--banner-section-->
      <section class="login-sec">
         <div class="container">
            <div class="row">
               <div class="col-12">
                  <div class=" ft-login d-flex bg-white">
                     <img src="vendor/img/main-img.png" class="img-fluid " alt="img">
                     <div class="form-structor">
                        <h2 class="main-heading mb-4 ">Welcome!</h2>
                        <!---login--->
                        <form id="login">
                           <div class="form-group">
                              <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                           </div>
                           <div class="form-group">
                              <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                           </div>
                           <div class="form-group">
                              <select class="form-control" id="exampleFormControlSelect1">
                              <option>Admin</option>
                              <option>Employee</option>
                            </select>
                           </div>
                           <button type="submit" class="btn btn-lg">Login</button>
                           <div class="form-group text-center">
                           <a href="#" class="reset-link">Forgot your password?</a>
                           </div>
                        </form>


                        <!----forget-password--->
                        <form id="reset-pswd" class="d-none">
                        <div class="form-group">
                        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                        </div>
                        <button type="submit" class="btn btn-lg w-auto">Reset Password</button>
                        </form>
                      </div>
                  </div>
               </div>
            </div>
            <div class="row mt-5">
               <div class=" col-12">
                  <p class="ft-info text-center text-white">Copyright © 2019 Master Creationz</p>
               </div>
            </div>
         </div>
      </section>
      
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="vendor/js/bootstrap.min.js"></script>
      <script src="vendor/js/main.js"></script>
      
   </body>
</html>