<html dir="ltr" lang="en-US">
   <head>
      <title>Attendance System</title>
      <meta http-equiv="content-type" content="text/html; charset=utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <meta name="author" content="" />
      <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,900&display=swap" rel="stylesheet" type="text/css" />
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800&display=swap" rel="stylesheet">
      <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
      <link rel="stylesheet" href="vendor/css/bootstrap.min.css" type="text/css" />
      <link rel="stylesheet" href="vendor/css/navigation.css" type="text/css">
      <link rel="stylesheet" href="vendor/css/style.css" type="text/css" />
      <link rel="stylesheet" href="vendor/css/responsive.css" type="text/css" />
   </head>
   <body>
      <nav class="navbar navbar-expand-lg navbar-light">
         <div class="container-fluid">
            <a class="navbar-brand" href="#"><img src="vendor/img/logo-img.png" class="img-fluid"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
               <p class="header-title">Time<br/>
               Management</p>
               <ul class="navbar-nav ml-auto">
                  <li class="nav-item dropdown">
                     <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     <img src="vendor/img/img1.jpg" class="img-fluid profile-pic">
                     </a>
                     <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <div class="az-header-profile">
                           <div class="az-img-user">
                              <img src="vendor/img/img1.jpg" alt="">
                           </div>
                           <!-- az-img-user -->
                           <h6>Aziana Pechon</h6>
                        </div>
                        <a href="" class="dropdown-item"><i class="fa fa-user mr-2"></i> My Profile</a>
                        <a href="" class="dropdown-item"><i class="fa fa-sign-out mr-2"></i> Log Out</a>
                     </div>
                  </li>
               </ul>
            </div>
         </div>
      </nav>
      <!---main-body-->
      <div id="wrapper">
         <!-----left-naviagtion--->
         <div class="pr-0 sidebar">
            <nav class="sidebar-offcanvas" id="sidebar">
               <ul class="d-block">
                  <li class="nav-item active">
                     <a class="nav-link" href="index.html">
                     <span class="menu-title">Dashboard</span>
                     <i class="fa fa-home"></i>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="#">
                     <span class="menu-title">Add Employee</span>
                     <i class="fa fa-user-o" aria-hidden="true"></i>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="#">
                     <span class="menu-title">Time Setting</span>
                     <i class="fa fa-clock-o" aria-hidden="true"></i>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="#">
                     <span class="menu-title">View Details</span>
                     <i class="fa fa-sticky-note-o" aria-hidden="true"></i>
                     </a>
                  </li>
               </ul>
            </nav>
         </div>
         <!-----dashboard--->
         <div id="content-wrapper" class="pt-4 px-4">
            <div class="container" id="dashboard">
               <div class="row">
                  <div class="col-12 mb-5">
                     <div class="d-flex align-items-center">
                        <span class="icon-box mr-3"><i class="fa fa-home"></i></span> 
                        <h2 class="top-heading">Dashboard</h2>
                     </div>
                  </div>
                  <div class="col-md-8 col-12">
                     <div class="card">
                        <div class="card-body">
                           <div class="current-date-box">
                              <span class="ct-date"> Friday, 28th June, 2019</span>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-4 col-12">
                     <div class="card">
                        <div class="card-body">
                           <div class="current-date-box">
                              <span class="ct-date">Current Time</span>
                           </div>
                           <div style="text-align:center;padding:1em 0;"><iframe src="https://www.zeitverschiebung.net/clock-widget-iframe-v2?language=en&size=medium&timezone=Asia%2FKolkata" width="100%" height="115" frameborder="0" seamless></iframe> </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-----add-employee--->
            <div class="container mt-5" id="add-employee">
               <div class="row">
                  <div class="col-12">
                     <div class="d-flex align-items-center">
                        <span class="icon-box mr-3"><i class="fa fa-user-o"></i></span> 
                        <h2 class="top-heading">Add Employee</h2>
                     </div>
                  </div>
                  <div class="col-md-7 col-12">
                     <div class="card mt-5">
                        <div class="card-body">
                           <form>
                              <div class="form-group mt-0">
                                 <label for="exampleInputEmail1">Email address</label>
                                 <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Email">
                              </div>
                              <div class="form-group">
                                 <label for="exampleInputPassword1">Password</label>
                                 <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                              </div>
                              <div class="form-group">
                                 <label for="exampleInputConfirmPassword1">Confirm Password</label>
                                 <input type="password" class="form-control" id="exampleInputConfirmPassword1" placeholder="Password">
                              </div>
                              <button type="submit" class="btn btn-lg" href="#">Submit</button>
                           </form>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-5 col-12">
                     <div class="card mt-5">
                        <div class="card-body mx-auto">
                           <form>
                              <div class="pie-chart">
                                 <img src="vendor/img/download.png" alt="avatar" class="pie-avatar img-circle">
                              </div>
                              <div class="form-group">
                                 <input type="file" class="form-control-file" id="exampleFormControlFile1">
                              </div>
                              <button type="submit" class="btn btn-lg" href="#">Update</button>
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!----time-setting--->
            <div class="container mt-5" id="time-setting">
               <div class="row">
                  <div class="col-12 mb-5">
                     <div class="d-flex align-items-center">
                        <span class="icon-box mr-3"><i class="fa fa-clock-o"></i></span> 
                        <h2 class="top-heading">Time Setting</h2>
                     </div>
                  </div>
                  <div class="col-md-4 col-12">
                     <div class="bg-white p-4 rounded time-set">
                        <h4 class="sm-label">Start Time</h4>
                        <div class="d-flex justify-content-between">
                           <div class="form-group">
                              <select class="form-control" id="exampleFormControlSelect1">
                                 <option>1</option>
                                 <option>2</option>
                                 <option>3</option>
                                 <option>4</option>
                                 <option>5</option>
                                 <option>6</option>
                                 <option>7</option>
                                 <option>8</option>
                                 <option>9</option>
                                 <option>10</option>
                                 <option>11</option>
                                 <option>12</option>
                              </select>
                           </div>
                           <div class="form-group">
                              <select class="form-control" id="exampleFormControlSelect1">
                                 <option>1</option>
                                 <option>2</option>
                                 <option>3</option>
                                 <option>4</option>
                                 <option>5</option>
                                 <option>6</option>
                                 <option>7</option>
                                 <option>8</option>
                                 <option>9</option>
                                 <option>10</option>
                                 <option>11</option>
                                 <option>12</option>
                                 <option>13</option>
                                 <option>14</option>
                                 <option>15</option>
                                 <option>16</option>
                                 <option>17</option>
                                 <option>18</option>
                                 <option>19</option>
                                 <option>20</option>
                                 <option>21</option>
                                 <option>22</option>
                                 <option>23</option>
                                 <option>24</option>
                                 <option>25</option>
                                 <option>26</option>
                                 <option>27</option>
                                 <option>28</option>
                                 <option>29</option>
                                 <option>30</option>
                                 <option>31</option>
                                 <option>32</option>
                                 <option>33</option>
                                 <option>34</option>
                                 <option>35</option>
                                 <option>36</option>
                                 <option>37</option>
                                 <option>38</option>
                                 <option>39</option>
                                 <option>40</option>
                                 <option>41</option>
                                 <option>42</option>
                                 <option>43</option>
                                 <option>44</option>
                                 <option>45</option>
                                 <option>46</option>
                                 <option>47</option>
                                 <option>48</option>
                                 <option>49</option>
                                 <option>50</option>
                                 <option>51</option>
                                 <option>52</option>
                                 <option>53</option>
                                 <option>54</option>
                                 <option>55</option>
                                 <option>56</option>
                                 <option>57</option>
                                 <option>58</option>
                                 <option>59</option>
                                 <option>53</option>
                                 <option>54</option>
                                 <option>55</option>
                                 <option>56</option>
                              </select>
                           </div>
                           <!-- <div class="form-group">
                              <select class="form-control" id="exampleFormControlSelect1">
                                 <option>am</option>
                                 <option>pm</option>
                              </select>
                           </div> -->
                        </div>
                     </div>
                  </div>
                  <div class="col-md-4 col-12">
                     <div class="bg-white p-4 rounded time-set">
                        <h4 class="sm-label">Last Time</h4>
                        <div class="d-flex justify-content-between">
                           <div class="form-group">
                              <select class="form-control" id="exampleFormControlSelect1">
                                 <option>1</option>
                                 <option>2</option>
                                 <option>3</option>
                                 <option>4</option>
                                 <option>5</option>
                                 <option>6</option>
                                 <option>7</option>
                                 <option>8</option>
                                 <option>9</option>
                                 <option>10</option>
                                 <option>11</option>
                                 <option>12</option>
                              </select>
                           </div>
                           <div class="form-group">
                              <select class="form-control" id="exampleFormControlSelect1">
                                 <option>1</option>
                                 <option>2</option>
                                 <option>3</option>
                                 <option>4</option>
                                 <option>5</option>
                                 <option>6</option>
                                 <option>7</option>
                                 <option>8</option>
                                 <option>9</option>
                                 <option>10</option>
                                 <option>11</option>
                                 <option>12</option>
                                 <option>13</option>
                                 <option>14</option>
                                 <option>15</option>
                                 <option>16</option>
                                 <option>17</option>
                                 <option>18</option>
                                 <option>19</option>
                                 <option>20</option>
                                 <option>21</option>
                                 <option>22</option>
                                 <option>23</option>
                                 <option>24</option>
                                 <option>25</option>
                                 <option>26</option>
                                 <option>27</option>
                                 <option>28</option>
                                 <option>29</option>
                                 <option>30</option>
                                 <option>31</option>
                                 <option>32</option>
                                 <option>33</option>
                                 <option>34</option>
                                 <option>35</option>
                                 <option>36</option>
                                 <option>37</option>
                                 <option>38</option>
                                 <option>39</option>
                                 <option>40</option>
                                 <option>41</option>
                                 <option>42</option>
                                 <option>43</option>
                                 <option>44</option>
                                 <option>45</option>
                                 <option>46</option>
                                 <option>47</option>
                                 <option>48</option>
                                 <option>49</option>
                                 <option>50</option>
                                 <option>51</option>
                                 <option>52</option>
                                 <option>53</option>
                                 <option>54</option>
                                 <option>55</option>
                                 <option>56</option>
                                 <option>57</option>
                                 <option>58</option>
                                 <option>59</option>
                                 <option>53</option>
                                 <option>54</option>
                                 <option>55</option>
                                 <option>56</option>
                              </select>
                           </div>
                           <!-- <div class="form-group">
                              <select class="form-control" id="exampleFormControlSelect1">
                                 <option>am</option>
                                 <option>pm</option>
                              </select>
                           </div> -->
                        </div>
                     </div>
                  </div>
                  <div class="col-md-4 col-12">
                     <div class="bg-white p-4 rounded time-set">
                        <h4 class="sm-label">Evening Time</h4>
                        <div class="d-flex justify-content-between">
                           <div class="form-group">
                              <select class="form-control" id="exampleFormControlSelect1">
                                 <option>1</option>
                                 <option>2</option>
                                 <option>3</option>
                                 <option>4</option>
                                 <option>5</option>
                                 <option>6</option>
                                 <option>7</option>
                                 <option>8</option>
                                 <option>9</option>
                                 <option>10</option>
                                 <option>11</option>
                                 <option>12</option>
                              </select>
                           </div>
                           <div class="form-group">
                              <select class="form-control" id="exampleFormControlSelect1">
                                 <option>1</option>
                                 <option>2</option>
                                 <option>3</option>
                                 <option>4</option>
                                 <option>5</option>
                                 <option>6</option>
                                 <option>7</option>
                                 <option>8</option>
                                 <option>9</option>
                                 <option>10</option>
                                 <option>11</option>
                                 <option>12</option>
                                 <option>13</option>
                                 <option>14</option>
                                 <option>15</option>
                                 <option>16</option>
                                 <option>17</option>
                                 <option>18</option>
                                 <option>19</option>
                                 <option>20</option>
                                 <option>21</option>
                                 <option>22</option>
                                 <option>23</option>
                                 <option>24</option>
                                 <option>25</option>
                                 <option>26</option>
                                 <option>27</option>
                                 <option>28</option>
                                 <option>29</option>
                                 <option>30</option>
                                 <option>31</option>
                                 <option>32</option>
                                 <option>33</option>
                                 <option>34</option>
                                 <option>35</option>
                                 <option>36</option>
                                 <option>37</option>
                                 <option>38</option>
                                 <option>39</option>
                                 <option>40</option>
                                 <option>41</option>
                                 <option>42</option>
                                 <option>43</option>
                                 <option>44</option>
                                 <option>45</option>
                                 <option>46</option>
                                 <option>47</option>
                                 <option>48</option>
                                 <option>49</option>
                                 <option>50</option>
                                 <option>51</option>
                                 <option>52</option>
                                 <option>53</option>
                                 <option>54</option>
                                 <option>55</option>
                                 <option>56</option>
                                 <option>57</option>
                                 <option>58</option>
                                 <option>59</option>
                                 <option>53</option>
                                 <option>54</option>
                                 <option>55</option>
                                 <option>56</option>
                              </select>
                           </div>
                           <!-- <div class="form-group">
                              <select class="form-control" id="exampleFormControlSelect1">
                                 <option>am</option>
                                 <option>pm</option>
                              </select>
                           </div> -->
                        </div>
                     </div>
                  </div>
                  <div class="col-12 text-right">
                     <button type="submit" class="btn btn-lg" href="#">Apply</button>
                  </div>
               </div>
            </div>
            <!----view-details--->
            <div class="container mt-5" id="view-details">
               <div class="row">
                  <div class="col-12 mb-5">
                     <div class="d-flex align-items-center">
                        <span class="icon-box mr-3"><i class="fa fa-sticky-note-o"></i></span> 
                        <h2 class="top-heading">View Details</h2>
                     </div>
                  </div>
                  <div class="col-12">
                     <div class="table-wrapper w-100 rounded">
                        <div class="table-filter">
                           <div class="row">
                              <div class="col-sm-3">
                                 <div class="show-entries">
                                    <span>Show</span>
                                    <select class="form-control">
                                       <option>5</option>
                                       <option>10</option>
                                       <option>15</option>
                                       <option>20</option>
                                    </select>
                                    <span>entries</span>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <table class="table table-striped table-hover">
                           <thead>
                              <tr>
                                 <th>No.</th>
                                 <th>Name</th>
                                 <th>Role</th>
                                 <th>Action</th>
                              </tr>
                           </thead>
                           <tbody>
                              <tr>
                                 <td>1</td>
                                 <td><a href="#"><img src="vendor/img/img1.jpg" class="avatar img-fluid" alt="Avatar"> Aziana Pechon</a></td>
                                 <td>Employee</td>
                                 <td>
                                    <div class="d-flex"><a href="#" class="sm-btn">View</a>
                                       <a href="#" class="sm-btn">Inactive</a>
                                    </div>
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                        <div class="clearfix">
                           <div class="hint-text">Showing <b>5</b> out of <b>25</b> entries</div>
                           <ul class="pagination">
                              <li class="page-item disabled"><a href="#">Previous</a></li>
                              <li class="page-item"><a href="#" class="page-link">1</a></li>
                              <li class="page-item"><a href="#" class="page-link">2</a></li>
                              <li class="page-item"><a href="#" class="page-link">3</a></li>
                              <li class="page-item active"><a href="#" class="page-link">4</a></li>
                              <li class="page-item"><a href="#" class="page-link">5</a></li>
                              <li class="page-item"><a href="#" class="page-link">6</a></li>
                              <li class="page-item"><a href="#" class="page-link">7</a></li>
                              <li class="page-item"><a href="#" class="page-link">Next</a></li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="vendor/js/bootstrap.min.js"></script>
      <script src="vendor/js/main.js"></script>
   </body>
</html>