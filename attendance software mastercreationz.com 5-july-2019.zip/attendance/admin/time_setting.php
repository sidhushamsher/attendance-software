<?php
session_start();
include 'vendor/php/admin_api.php';
$obj	=	new api();
?>
<html dir="ltr" lang="en-US">
   <head>
      <?php
      $obj->head_script();
      ?>
   </head>
   <body>
      <?php
      $obj->nav_bar();
      //$obj->main('dashboard');
      $obj->main('timeset');
      //	$obj->main('addemp');
      $obj->footer_script();
      /*
      $obj->main('viewemp');
      */
    
		$conn_obj	=	new conn;
		$sql	=	"SELECT * FROM timetable";
		$sqlQ	=	$conn_obj->sqlQuery_S($sql);
		$data	=	mysqli_fetch_assoc($sqlQ['exe']);
		?>
		<script type="text/javascript">
		$("select[name='first_zone_hour']").val("<?=$data['first_zone_hour']?>");
		$("select[name='first_zone_mintue']").val("<?=$data['first_zone_mintue']?>");
		$("select[name='second_zone_hour']").val("<?=$data['second_zone_hour']?>");
		$("select[name='second_zone_mintue']").val("<?=$data['second_zone_mintue']?>");
		$("select[name='third_zone_hour']").val("<?=$data['third_zone_hour']?>");
		$("select[name='third_zone_mintue']").val("<?=$data['third_zone_mintue']?>");

		</script>

   </body>
</html>
