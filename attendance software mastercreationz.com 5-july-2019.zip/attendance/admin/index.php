<?php
session_start();
include 'vendor/php/admin_api.php';
$obj	=	new api();
?>
<html dir="ltr" lang="en-US">
   <head>
      <?php
      $obj->head_script();
      ?>
   </head>
   <body>
      <?php
      $obj->nav_bar();
      $obj->main('dashboard');
      $obj->footer_script();
      /*$obj->main('addemp');
      $obj->main('timeset');
      $obj->main('viewemp');*/
      ?>

   </body>
</html>