<?php
	session_start();
	include 'vendor/php/admin_api.php';
	$obj	=	new api();

	if (!isset($_GET['id']) || !isset($_GET['for'])) {
		$conn_obj->f0f();
		return;
	}
	$sql	=	"SELECT * FROM staff_details WHERE staff_uniqid='".$_GET['id']."'";
	$sqlQ	=	$conn_obj->sqlQuery_S($sql);
	if ($sqlQ['rows']<1) {
		# code...
		$conn_obj->f0f();
		return;
	}
	switch ($_GET['for']) {
		case 'inactive':
			# code...
		$sql1	=	"UPDATE staff_details SET status='2' WHERE staff_uniqid='".$_GET['id']."'";
		$sql2	=	"UPDATE users SET user_status='2' WHERE staff_uniqid='".$_GET['id']."'";
			break;
		case 'active':
			# code...
		$sql1	=	"UPDATE staff_details SET status='1' WHERE staff_uniqid='".$_GET['id']."'";
		$sql2	=	"UPDATE users SET user_status='1' WHERE staff_uniqid='".$_GET['id']."'";
			break;
		case 'delete':
			# code...
		$sql1	=	"UPDATE staff_details SET status='3' WHERE staff_uniqid='".$_GET['id']."'";
		$sql2	=	"UPDATE users SET user_status='3' WHERE staff_uniqid='".$_GET['id']."'";
		$sql3	=	"UPDATE att_details SET att_status='d' WHERE staff_uniqid='".$_GET['id']."'";
		$conn_obj->sqlQuery_U($sql3);

			break;
				
		default:
			# code...
			$conn_obj->f0f();
			break;
	}
	$conn_obj->sqlQuery_U($sql1);
	$conn_obj->sqlQuery_U($sql2);
	$conn_obj->go_back('viewStaff.php');

	

?>