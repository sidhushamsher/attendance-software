<?php
header("location:login.php");
?>