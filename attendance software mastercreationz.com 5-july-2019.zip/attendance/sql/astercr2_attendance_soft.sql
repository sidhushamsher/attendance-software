-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 05, 2019 at 05:49 AM
-- Server version: 5.6.41-84.1
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `astercr2_attendance_soft`
--

-- --------------------------------------------------------

--
-- Table structure for table `att_details`
--

CREATE TABLE `att_details` (
  `id` int(255) NOT NULL,
  `staff_uniqid` varchar(1000) NOT NULL,
  `att_date` varchar(1000) NOT NULL,
  `att_in_time` varchar(1000) NOT NULL DEFAULT '1',
  `att_out_time` varchar(1000) NOT NULL DEFAULT '1',
  `att_in_time_status` varchar(1000) NOT NULL DEFAULT '1',
  `att_out_time_status` varchar(1000) NOT NULL DEFAULT '1',
  `att_in_time_maked_by` varchar(1000) NOT NULL DEFAULT '2',
  `att_out_time_maked_by` varchar(1000) NOT NULL DEFAULT '2',
  `att_total_time` varchar(1000) NOT NULL DEFAULT '0',
  `att_in_reason` varchar(1000) NOT NULL DEFAULT '1',
  `att_out_reason` varchar(1000) NOT NULL DEFAULT '1',
  `att_in_ip` varchar(1000) NOT NULL DEFAULT '1',
  `att_out_ip` varchar(1000) NOT NULL DEFAULT '1',
  `att_status` varchar(1000) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `att_details`
--

INSERT INTO `att_details` (`id`, `staff_uniqid`, `att_date`, `att_in_time`, `att_out_time`, `att_in_time_status`, `att_out_time_status`, `att_in_time_maked_by`, `att_out_time_maked_by`, `att_total_time`, `att_in_reason`, `att_out_reason`, `att_in_ip`, `att_out_ip`, `att_status`, `created_at`, `updated_at`) VALUES
(1, '5d1f13e5841e7', '05-07-2019', '1', '1', '1', '1', '2', '2', '0', '1', '1', '1', '1', '1', '2019-07-05 11:43:56', '2019-07-05 11:43:56'),
(2, '5d1f1405552be', '05-07-2019', '1', '1', '1', '1', '2', '2', '0', '1', '1', '1', '1', '1', '2019-07-05 11:43:56', '2019-07-05 11:43:56'),
(3, '5d1f142535483', '05-07-2019', '1', '1', '1', '1', '2', '2', '0', '1', '1', '1', '1', '1', '2019-07-05 11:43:56', '2019-07-05 11:43:56'),
(4, '5d1f31b8c7475', '05-07-2019', '1', '1', '1', '1', '2', '2', '0', '1', '1', '1', '1', '1', '2019-07-05 11:43:56', '2019-07-05 11:43:56'),
(5, '5d1f38b3b85f6', '05-07-2019', '1', '1', '1', '1', '2', '2', '0', '1', '1', '1', '1', '1', '2019-07-05 11:47:01', '2019-07-05 11:47:01');

-- --------------------------------------------------------

--
-- Table structure for table `profile_data`
--

CREATE TABLE `profile_data` (
  `id` int(255) NOT NULL,
  `profile_name` varchar(1000) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(1000) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile_data`
--

INSERT INTO `profile_data` (`id`, `profile_name`, `created_at`, `updated_at`, `status`) VALUES
(1, 'designer', '2019-07-01 11:25:32', '2019-07-01 12:12:22', '1'),
(2, 'manager', '2019-07-01 11:25:32', '2019-07-01 11:25:32', '1'),
(3, 'developer', '2019-07-05 11:46:08', '2019-07-05 11:46:08', '1');

-- --------------------------------------------------------

--
-- Table structure for table `staff_details`
--

CREATE TABLE `staff_details` (
  `id` int(255) NOT NULL,
  `staff_uniqid` varchar(1000) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `email` varchar(1000) NOT NULL,
  `staff_image` varchar(1000) NOT NULL DEFAULT '1',
  `profile` varchar(1000) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(1000) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff_details`
--

INSERT INTO `staff_details` (`id`, `staff_uniqid`, `name`, `email`, `staff_image`, `profile`, `created_at`, `updated_at`, `status`) VALUES
(1, '5d1f13e5841e7', 'Vishal', 'vishal@mastercreationz.com', '1', '1', '2019-07-05 09:09:57', '2019-07-05 11:42:18', '1'),
(2, '5d1f1405552be', 'Robin Mehta', 'robin@mastercreationz.com', '1', '1', '2019-07-05 09:10:29', '2019-07-05 11:42:13', '1'),
(3, '5d1f142535483', 'Honey Rathor', 'honey@mastercreationz.com', '1', '1', '2019-07-05 09:11:01', '2019-07-05 09:11:01', '1'),
(4, '5d1f31b8c7475', 'Mayabhatia', 'mayabhatia@mastercreationz.com', '1', '1', '2019-07-05 11:17:12', '2019-07-05 11:17:12', '1'),
(5, '5d1f38b3b85f6', 'Shamsher', 'shamsher@mastercreationz.com', '1', '3', '2019-07-05 11:46:59', '2019-07-05 11:46:59', '1');

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE `timetable` (
  `id` int(255) NOT NULL,
  `first_zone_hour` varchar(1000) NOT NULL,
  `first_zone_mintue` varchar(1000) NOT NULL,
  `second_zone_hour` varchar(1000) NOT NULL,
  `second_zone_mintue` varchar(1000) NOT NULL,
  `third_zone_hour` varchar(1000) NOT NULL,
  `third_zone_mintue` varchar(1000) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(1000) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`id`, `first_zone_hour`, `first_zone_mintue`, `second_zone_hour`, `second_zone_mintue`, `third_zone_hour`, `third_zone_mintue`, `created_at`, `updated_at`, `status`) VALUES
(1, '09', '00', '10', '00', '19', '00', '2019-06-26 08:54:25', '2019-07-04 07:07:32', '1');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(255) NOT NULL,
  `email` varchar(1000) NOT NULL,
  `staff_uniqid` varchar(1000) NOT NULL DEFAULT '1',
  `name` varchar(1000) NOT NULL DEFAULT '1',
  `password` varchar(1000) NOT NULL,
  `role` int(11) NOT NULL,
  `profile` varchar(1000) NOT NULL DEFAULT '1',
  `user_status` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `staff_uniqid`, `name`, `password`, `role`, `profile`, `user_status`, `created_at`, `updated_at`) VALUES
(1, 'admin@mastercreationz.com', '1', 'admin', '123', 1, '1', 1, '2019-06-21 09:49:06', '2019-07-05 11:43:51'),
(47, 'vishal@mastercreationz.com', '5d1f13e5841e7', 'Vishal', '123123', 2, '1', 1, '2019-07-05 09:09:57', '2019-07-05 09:09:57'),
(48, 'robin@mastercreationz.com', '5d1f1405552be', 'Robin Mehta', '123123', 2, '1', 1, '2019-07-05 09:10:29', '2019-07-05 09:10:29'),
(49, 'honey@mastercreationz.com', '5d1f142535483', 'Honey Rathor', '123123', 2, '1', 1, '2019-07-05 09:11:01', '2019-07-05 09:11:01'),
(50, 'maya@mastercreationz.com', '5d1f31b8c7475', 'Mayabhatia', '123123', 2, '1', 1, '2019-07-05 11:17:12', '2019-07-05 11:44:27'),
(51, 'shamsher@mastercreationz.com', '5d1f38b3b85f6', 'Shamsher', '123123', 2, '3', 1, '2019-07-05 11:46:59', '2019-07-05 11:46:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `att_details`
--
ALTER TABLE `att_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile_data`
--
ALTER TABLE `profile_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff_details`
--
ALTER TABLE `staff_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `timetable`
--
ALTER TABLE `timetable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `att_details`
--
ALTER TABLE `att_details`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `profile_data`
--
ALTER TABLE `profile_data`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `staff_details`
--
ALTER TABLE `staff_details`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `timetable`
--
ALTER TABLE `timetable`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
