-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 04, 2019 at 07:51 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo_soft`
--

-- --------------------------------------------------------

--
-- Table structure for table `att_details`
--

CREATE TABLE `att_details` (
  `id` int(255) NOT NULL,
  `staff_uniqid` varchar(1000) NOT NULL,
  `att_date` varchar(1000) NOT NULL,
  `att_in_time` varchar(1000) NOT NULL DEFAULT '1',
  `att_out_time` varchar(1000) NOT NULL DEFAULT '1',
  `att_in_time_status` varchar(1000) NOT NULL DEFAULT '1',
  `att_out_time_status` varchar(1000) NOT NULL DEFAULT '1',
  `att_in_time_maked_by` varchar(1000) NOT NULL DEFAULT '2',
  `att_out_time_maked_by` varchar(1000) NOT NULL DEFAULT '2',
  `att_total_time` varchar(1000) NOT NULL DEFAULT '0',
  `att_status` varchar(1000) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `profile_data`
--

CREATE TABLE `profile_data` (
  `id` int(255) NOT NULL,
  `profile_name` varchar(1000) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(1000) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile_data`
--

INSERT INTO `profile_data` (`id`, `profile_name`, `created_at`, `updated_at`, `status`) VALUES
(1, 'designer', '2019-07-01 11:25:32', '2019-07-01 12:12:22', '1'),
(2, 'manager', '2019-07-01 11:25:32', '2019-07-01 11:25:32', '1');

-- --------------------------------------------------------

--
-- Table structure for table `staff_details`
--

CREATE TABLE `staff_details` (
  `id` int(255) NOT NULL,
  `staff_uniqid` varchar(1000) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `email` varchar(1000) NOT NULL,
  `staff_image` varchar(1000) NOT NULL DEFAULT '1',
  `profile` varchar(1000) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(1000) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE `timetable` (
  `id` int(255) NOT NULL,
  `first_zone_hour` varchar(1000) NOT NULL,
  `first_zone_mintue` varchar(1000) NOT NULL,
  `second_zone_hour` varchar(1000) NOT NULL,
  `second_zone_mintue` varchar(1000) NOT NULL,
  `third_zone_hour` varchar(1000) NOT NULL,
  `third_zone_mintue` varchar(1000) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(1000) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`id`, `first_zone_hour`, `first_zone_mintue`, `second_zone_hour`, `second_zone_mintue`, `third_zone_hour`, `third_zone_mintue`, `created_at`, `updated_at`, `status`) VALUES
(1, '09', '00', '18', '00', '19', '00', '2019-06-26 08:54:25', '2019-07-02 12:25:54', '1');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(255) NOT NULL,
  `email` varchar(1000) NOT NULL,
  `staff_uniqid` varchar(1000) NOT NULL DEFAULT '1',
  `name` varchar(1000) NOT NULL DEFAULT '1',
  `password` varchar(1000) NOT NULL,
  `role` int(11) NOT NULL,
  `profile` varchar(1000) NOT NULL DEFAULT '1',
  `user_status` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `staff_uniqid`, `name`, `password`, `role`, `profile`, `user_status`, `created_at`, `updated_at`) VALUES
(1, 'shamshersidhu654@gmail.com', '1', '1', '123', 1, '1', 1, '2019-06-21 09:49:06', '2019-06-21 09:49:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `att_details`
--
ALTER TABLE `att_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile_data`
--
ALTER TABLE `profile_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff_details`
--
ALTER TABLE `staff_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `timetable`
--
ALTER TABLE `timetable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `att_details`
--
ALTER TABLE `att_details`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `profile_data`
--
ALTER TABLE `profile_data`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `staff_details`
--
ALTER TABLE `staff_details`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `timetable`
--
ALTER TABLE `timetable`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
