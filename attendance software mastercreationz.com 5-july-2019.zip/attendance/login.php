<?php
session_start();
include 'vendor/php/login_api.php';
$obj     =    new login_api();
if (isset($_POST['submit'])) {
   # code...
   $email   =  strtolower($_POST['email']);
   $password   =  $_POST['password'];
   $role =  $_POST['role'];
   
   $sql  =  "SELECT * FROM users WHERE email='$email' AND password='$password' AND role='$role' AND user_status='1'";
   $sqlQ =  $obj->sqlQuery_S($sql);

   if ($sqlQ['rows'] > 0) {
      # code...
      $data =  mysqli_fetch_assoc($sqlQ['exe']);
      $_SESSION['user_logged_in']   =  $data;
      header('location:login.php');
   }
   else{
      header('location:login.php?error');

   }
}
?>
<html dir="ltr" lang="en-US">
   <head>
      <?php
      $obj->head_script();
      ?>
   </head>
   <body>
      <?php
     
      /*$obj->main('addemp');
      $obj->main('timeset');
      $obj->main('viewemp');*/
      ?>
       <section class="login-sec">
         <div class="container">
            <div class="row">
               <div class="col-12">
                  <div class=" ft-login d-md-flex d-block bg-white">
                     <img src="vendor/img/main-img.png" class="img-fluid " alt="img">
                     <div class="form-structor">
                        <h2 class="main-heading mb-4 ">Welcome!</h2>
                        <!---login--->
                        <form id="login" method="post">
                           <div class="form-group">
                              <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                           </div>
                           <div class="form-group">
                              <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                           </div>
                           <div class="form-group">
                              <select name="role" class="form-control" id="exampleFormControlSelect1">
                              <option value="2">Employee</option>
                              <option value="1">Admin</option>
                            </select>
                           </div>
                           <input type="submit" name="submit" class="btn btn-lg" value="Login">
                           
                        </form>


                       
                      </div>
                  </div>
               </div>
            </div>
            <div class="row mt-5">
               <div class=" col-12">
                  <p class="ft-info text-center text-white">Copyright © 2019 Master Creationz</p>
               </div>
            </div>
         </div>
      </section>

<?php
      $obj->footer_script();
if (isset($_GET['error'])) {
   # code...
?>
<script>swal ( "ERROR" ,  "User not found!" ,  "error" )</script>
<?php
}
?>

   </body>
</html>
